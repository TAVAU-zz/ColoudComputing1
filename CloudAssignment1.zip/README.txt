This one is not work!
ELB URL(wang.yuhan2@husky.neu.edu): cloudYuhan.us-east-2.elasticbeanstalk.com

This one works:)
ELB URL(yuhanwang001@gmail.com): http://csye6225-env.25auac3tzp.us-east-2.elasticbeanstalk.com/
gitHub: https://github.com/TAVAU/CloudComputing